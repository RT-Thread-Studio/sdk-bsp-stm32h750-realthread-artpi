#include "stm32746g_discovery_lcd.h"
#include "stm32746g_discovery_ts.h"
#include "main.h"
/* Private define ------------------------------------------------------------*/
#define TOUCH_DOWN_XMIN         330
#define TOUCH_DOWN_XMAX         390
#define TOUCH_DOWN_YMIN         185
#define TOUCH_DOWN_YMAX         245

#define TOUCH_UP_XMIN     330
#define TOUCH_UP_XMAX     390
#define TOUCH_UP_YMIN     25
#define TOUCH_UP_YMAX     85

#define TOUCH_LEFT_XMIN         260
#define TOUCH_LEFT_XMAX         320
#define TOUCH_LEFT_YMIN         105
#define TOUCH_LEFT_YMAX         165

#define TOUCH_RIGHT_XMIN        400
#define TOUCH_RIGHT_XMAX        460
#define TOUCH_RIGHT_YMIN        105
#define TOUCH_RIGHT_YMAX        165

#define NONE 0
#define RIGHT 1
#define LEFT 2
#define UP 3
#define DOWN 4


/**
  * @brief  Display interface touch screen buttons
  * @param  None
  * @retval None
  */
void AUDIO_PlaybackDisplayButtons(void)
{
  BSP_LCD_FillRect(TOUCH_UP_XMIN, TOUCH_UP_YMIN , TOUCH_UP_XMAX-TOUCH_UP_XMIN, TOUCH_UP_YMAX - TOUCH_UP_YMIN);
  BSP_LCD_FillRect(TOUCH_RIGHT_XMIN, TOUCH_RIGHT_YMIN , TOUCH_RIGHT_XMAX-TOUCH_RIGHT_XMIN, TOUCH_RIGHT_YMAX - TOUCH_RIGHT_YMIN);    /* RIGHT rectangles */
  BSP_LCD_FillRect(TOUCH_DOWN_XMIN , TOUCH_DOWN_YMIN,TOUCH_DOWN_XMAX-TOUCH_DOWN_XMIN , TOUCH_DOWN_YMAX - TOUCH_DOWN_YMIN);
  BSP_LCD_FillRect(TOUCH_LEFT_XMIN, TOUCH_LEFT_YMIN , /* LEFT rectangle */
                   TOUCH_LEFT_XMAX - TOUCH_LEFT_XMIN,
                   TOUCH_LEFT_YMAX - TOUCH_LEFT_YMIN);
}

/**
  * @brief  Test touch screen state and modify audio state machine according to that
  * @param  None
  * @retval None
  */
char NES_AcquireTouchButtons(void)
{
  static TS_StateTypeDef  TS_State={0};
	static char key_state;

  if(TS_State.touchDetected == 1)   /* If UP touch has not been released, we don't proceed any touch command */
  {
    BSP_TS_GetState(&TS_State);
  }
  else
  {
		BSP_TS_GetState(&TS_State);
    if(TS_State.touchDetected == 1)
    {
      if ((TS_State.touchX[0] > TOUCH_RIGHT_XMIN) && (TS_State.touchX[0] < TOUCH_RIGHT_XMAX) &&
          (TS_State.touchY[0] > TOUCH_RIGHT_YMIN) && (TS_State.touchY[0] < TOUCH_RIGHT_YMAX))
      {
        key_state= UP;
      }
      else if ((TS_State.touchX[0] > TOUCH_DOWN_XMIN) && (TS_State.touchX[0] < TOUCH_DOWN_XMAX) &&
               (TS_State.touchY[0] > TOUCH_DOWN_YMIN) && (TS_State.touchY[0] < TOUCH_DOWN_YMAX))
      {
        key_state= RIGHT;
      }
      else if ((TS_State.touchX[0] > TOUCH_UP_XMIN) && (TS_State.touchX[0] < TOUCH_UP_XMAX) &&
               (TS_State.touchY[0] > TOUCH_UP_YMIN) && (TS_State.touchY[0] < TOUCH_UP_YMAX))
      {
        key_state= LEFT;
      }
      else if ((TS_State.touchX[0] > TOUCH_LEFT_XMIN) && (TS_State.touchX[0] < TOUCH_LEFT_XMAX) &&
               (TS_State.touchY[0] > TOUCH_LEFT_YMIN) && (TS_State.touchY[0] < TOUCH_LEFT_YMAX))
      {
        key_state= DOWN;
      }
      else
			{
				key_state= NONE;
			}
    }
		else
			key_state= NONE;
  }
	return key_state;
}